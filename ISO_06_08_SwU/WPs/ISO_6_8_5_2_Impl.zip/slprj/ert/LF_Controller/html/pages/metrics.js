function CodeMetrics() {
	 this.metricsArray = {};
	 this.metricsArray.var = new Array();
	 this.metricsArray.fcn = new Array();
	 this.metricsArray.fcn["ControllerModeSelector"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\ControllerModeSelector\\ControllerModeSelector.c",
	stack: 8,
	stackTotal: 8};
	 this.metricsArray.fcn["LF_Controller"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\LF_Controller\\LF_Controller.c",
	stack: 8,
	stackTotal: 71225};
	 this.metricsArray.fcn["LF_Controller_Init"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\LF_Controller\\LF_Controller.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LF_Controller_initialize"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\LF_Controller\\LF_Controller.c",
	stack: 0,
	stackTotal: 12};
	 this.metricsArray.fcn["MPCController"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\MPCController\\MPCController.c",
	stack: 49,
	stackTotal: 71217};
	 this.metricsArray.fcn["MPCController_Init"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\MPCController\\MPCController.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["MPCController_initialize"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\MPCController\\MPCController.c",
	stack: 12,
	stackTotal: 12};
	 this.metricsArray.fcn["WDGBrakingController"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\WDGBrakingController\\WDGBrakingController.c",
	stack: 40,
	stackTotal: 64};
	 this.metricsArray.fcn["WDGBrakingController_Init"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\WDGBrakingController\\WDGBrakingController.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["WDGBrakingController_initialize"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\WDGBrakingController\\WDGBrakingController.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["memset"] = {file: "T:\\jobarchive\\Bmain\\2021_09_16_h11m17s30_job1767943_pass\\matlab\\polyspace\\verifier\\cxx\\include\\include-libc\\string.h",
	stack: 0,
	stackTotal: 0};
	 this.getMetrics = function(token) { 
		 var data;
		 data = this.metricsArray.var[token];
		 if (!data) {
			 data = this.metricsArray.fcn[token];
			 if (data) data.type = "fcn";
		 } else { 
			 data.type = "var";
		 }
	 return data; }; 
	 this.codeMetricsSummary = '<a href="javascript:void(0)" onclick="return postParentWindowMessage({message:\'gotoReportPage\', pageName:\'LF_Controller_metrics\'});">Global Memory: 0(bytes) Maximum Stack: 49(bytes)</a>';
	}
CodeMetrics.instance = new CodeMetrics();
