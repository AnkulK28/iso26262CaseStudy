function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "WDGBrakingController"};
	this.sidHashMap["WDGBrakingController"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<Root>/mioDistance"] = {sid: "WDGBrakingController:24"};
	this.sidHashMap["WDGBrakingController:24"] = {rtwname: "<Root>/mioDistance"};
	this.rtwnameHashMap["<Root>/mioVelocity"] = {sid: "WDGBrakingController:25"};
	this.sidHashMap["WDGBrakingController:25"] = {rtwname: "<Root>/mioVelocity"};
	this.rtwnameHashMap["<Root>/egoVelocity"] = {sid: "WDGBrakingController:27"};
	this.sidHashMap["WDGBrakingController:27"] = {rtwname: "<Root>/egoVelocity"};
	this.rtwnameHashMap["<Root>/BrakeTimeCalculation"] = {sid: "WDGBrakingController:22"};
	this.sidHashMap["WDGBrakingController:22"] = {rtwname: "<Root>/BrakeTimeCalculation"};
	this.rtwnameHashMap["<Root>/TTCCalculation"] = {sid: "WDGBrakingController:21"};
	this.sidHashMap["WDGBrakingController:21"] = {rtwname: "<Root>/TTCCalculation"};
	this.rtwnameHashMap["<Root>/WDGBrakingLogic"] = {sid: "WDGBrakingController:26"};
	this.sidHashMap["WDGBrakingController:26"] = {rtwname: "<Root>/WDGBrakingLogic"};
	this.rtwnameHashMap["<Root>/BrakeStatus"] = {sid: "WDGBrakingController:28"};
	this.sidHashMap["WDGBrakingController:28"] = {rtwname: "<Root>/BrakeStatus"};
	this.rtwnameHashMap["<Root>/decel"] = {sid: "WDGBrakingController:29"};
	this.sidHashMap["WDGBrakingController:29"] = {rtwname: "<Root>/decel"};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
