function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "DetectMIOLaneCenter"};
	this.sidHashMap["DetectMIOLaneCenter"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<Root>/Lanes"] = {sid: "DetectMIOLaneCenter:28"};
	this.sidHashMap["DetectMIOLaneCenter:28"] = {rtwname: "<Root>/Lanes"};
	this.rtwnameHashMap["<Root>/confirmedTracks"] = {sid: "DetectMIOLaneCenter:29"};
	this.sidHashMap["DetectMIOLaneCenter:29"] = {rtwname: "<Root>/confirmedTracks"};
	this.rtwnameHashMap["<Root>/CoordinateChange"] = {sid: "DetectMIOLaneCenter:30"};
	this.sidHashMap["DetectMIOLaneCenter:30"] = {rtwname: "<Root>/CoordinateChange"};
	this.rtwnameHashMap["<Root>/EstimateLaneCenter"] = {sid: "DetectMIOLaneCenter:31"};
	this.sidHashMap["DetectMIOLaneCenter:31"] = {rtwname: "<Root>/EstimateLaneCenter"};
	this.rtwnameHashMap["<Root>/FindLeadCar"] = {sid: "DetectMIOLaneCenter:32"};
	this.sidHashMap["DetectMIOLaneCenter:32"] = {rtwname: "<Root>/FindLeadCar"};
	this.rtwnameHashMap["<Root>/Terminator"] = {sid: "DetectMIOLaneCenter:33"};
	this.sidHashMap["DetectMIOLaneCenter:33"] = {rtwname: "<Root>/Terminator"};
	this.rtwnameHashMap["<Root>/LaneCenter"] = {sid: "DetectMIOLaneCenter:34"};
	this.sidHashMap["DetectMIOLaneCenter:34"] = {rtwname: "<Root>/LaneCenter"};
	this.rtwnameHashMap["<Root>/mioRelativeDistance"] = {sid: "DetectMIOLaneCenter:35"};
	this.sidHashMap["DetectMIOLaneCenter:35"] = {rtwname: "<Root>/mioRelativeDistance"};
	this.rtwnameHashMap["<Root>/mioRelativeVelocity"] = {sid: "DetectMIOLaneCenter:36"};
	this.sidHashMap["DetectMIOLaneCenter:36"] = {rtwname: "<Root>/mioRelativeVelocity"};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
