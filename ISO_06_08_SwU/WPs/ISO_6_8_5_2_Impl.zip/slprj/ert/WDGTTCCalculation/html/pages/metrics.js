function CodeMetrics() {
	 this.metricsArray = {};
	 this.metricsArray.var = new Array();
	 this.metricsArray.fcn = new Array();
	 this.metricsArray.fcn["WDGTTCCalculation"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\WDGTTCCalculation\\WDGTTCCalculation.c",
	stack: 24,
	stackTotal: 24};
	 this.metricsArray.fcn["WDGTTCCalculation_initialize"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\WDGTTCCalculation\\WDGTTCCalculation.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["fabs"] = {file: "T:\\jobarchive\\Bmain\\2021_09_16_h11m17s30_job1767943_pass\\matlab\\polyspace\\verifier\\cxx\\include\\include-libc\\bits\\mathcalls.h",
	stack: 0,
	stackTotal: 0};
	 this.getMetrics = function(token) { 
		 var data;
		 data = this.metricsArray.var[token];
		 if (!data) {
			 data = this.metricsArray.fcn[token];
			 if (data) data.type = "fcn";
		 } else { 
			 data.type = "var";
		 }
	 return data; }; 
	 this.codeMetricsSummary = '<a href="javascript:void(0)" onclick="return postParentWindowMessage({message:\'gotoReportPage\', pageName:\'WDGTTCCalculation_metrics\'});">Global Memory: 0(bytes) Maximum Stack: 24(bytes)</a>';
	}
CodeMetrics.instance = new CodeMetrics();
