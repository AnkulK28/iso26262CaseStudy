function CodeMetrics() {
	 this.metricsArray = {};
	 this.metricsArray.var = new Array();
	 this.metricsArray.fcn = new Array();
	 this.metricsArray.fcn["DropConstraint_qA3GI0eX_ASILD"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\_sharedutils\\DropConstraint_qA3GI0eX_ASILD.c",
	stack: 14,
	stackTotal: 14};
	 this.metricsArray.fcn["KWIKfactor_a8xdMRpH_ASILD"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\_sharedutils\\KWIKfactor_a8xdMRpH_ASILD.c",
	stack: 1286,
	stackTotal: 1932};
	 this.metricsArray.fcn["MPCC_PathFollowingControlSystem"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\MPCController\\MPCC_PathFollowingControlSystem.c",
	stack: 43214,
	stackTotal: 71168};
	 this.metricsArray.fcn["MPCC_PathFollowingControlSystem.c:MPCControlle_mpcblock_optimizer"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\MPCController\\MPCC_PathFollowingControlSystem.c",
	stack: 22507,
	stackTotal: 27954};
	 this.metricsArray.fcn["MPCCont_DataTypeConversion_amax"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\MPCController\\MPCC_PathFollowingControlSystem.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["MPCContro_DataTypeConversion_Vx"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\MPCController\\MPCC_PathFollowingControlSystem.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["MPCContro_DataTypeConversion_e1"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\MPCController\\MPCC_PathFollowingControlSystem.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["MPCController"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\MPCController\\MPCController.c",
	stack: 49,
	stackTotal: 71217};
	 this.metricsArray.fcn["MPCController_Init"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\MPCController\\MPCController.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["MPCController_initialize"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\MPCController\\MPCController.c",
	stack: 12,
	stackTotal: 12};
	 this.metricsArray.fcn["PadeApproximantO_IadiOITd_ASILD"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\_sharedutils\\PadeApproximantO_IadiOITd_ASILD.c",
	stack: 11896,
	stackTotal: 13024};
	 this.metricsArray.fcn["PathFollowingControlSystem_Init"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\MPCController\\MPCC_PathFollowingControlSystem.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Unconstrained_yqrrq9zw_ASILD"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\_sharedutils\\Unconstrained_yqrrq9zw_ASILD.c",
	stack: 16,
	stackTotal: 16};
	 this.metricsArray.fcn["WtMult_ACl0eGFr_ASILD"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\_sharedutils\\WtMult_ACl0eGFr_ASILD.c",
	stack: 38,
	stackTotal: 38};
	 this.metricsArray.fcn["abs_MNoTU925_ASILD"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\_sharedutils\\abs_MNoTU925_ASILD.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["abs_ZbB77Og9_ASILD"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\_sharedutils\\abs_ZbB77Og9_ASILD.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["asr_s32_ASILD"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\_sharedutils\\asr_s32_ASILD.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["ceil"] = {file: "T:\\jobarchive\\Bmain\\2021_09_16_h11m17s30_job1767943_pass\\matlab\\polyspace\\verifier\\cxx\\include\\include-libc\\bits\\mathcalls.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["expmNoLog2_AFCPMfdM_ASILD"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\_sharedutils\\expmNoLog2_AFCPMfdM_ASILD.c",
	stack: 1013,
	stackTotal: 14037};
	 this.metricsArray.fcn["fabs"] = {file: "T:\\jobarchive\\Bmain\\2021_09_16_h11m17s30_job1767943_pass\\matlab\\polyspace\\verifier\\cxx\\include\\include-libc\\bits\\mathcalls.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["floor"] = {file: "T:\\jobarchive\\Bmain\\2021_09_16_h11m17s30_job1767943_pass\\matlab\\polyspace\\verifier\\cxx\\include\\include-libc\\bits\\mathcalls.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["fmax"] = {file: "T:\\jobarchive\\Bmain\\2021_09_16_h11m17s30_job1767943_pass\\matlab\\polyspace\\verifier\\cxx\\include\\include-libc\\bits\\mathcalls.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["log"] = {file: "T:\\jobarchive\\Bmain\\2021_09_16_h11m17s30_job1767943_pass\\matlab\\polyspace\\verifier\\cxx\\include\\include-libc\\bits\\mathcalls.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["maximum2_HFCADrbr_ASILD"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\_sharedutils\\maximum2_HFCADrbr_ASILD.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["maximum_5j5McOZo_ASILD"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\_sharedutils\\maximum_5j5McOZo_ASILD.c",
	stack: 20,
	stackTotal: 20};
	 this.metricsArray.fcn["memcpy"] = {file: "T:\\jobarchive\\Bmain\\2021_09_16_h11m17s30_job1767943_pass\\matlab\\polyspace\\verifier\\cxx\\include\\include-libc\\string.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["memset"] = {file: "T:\\jobarchive\\Bmain\\2021_09_16_h11m17s30_job1767943_pass\\matlab\\polyspace\\verifier\\cxx\\include\\include-libc\\string.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["mldivide_M9TTPEHi_ASILD"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\_sharedutils\\mldivide_M9TTPEHi_ASILD.c",
	stack: 1128,
	stackTotal: 1128};
	 this.metricsArray.fcn["mpc_checkhessian_NqOOf1W5_ASILD"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\_sharedutils\\mpc_checkhessian_NqOOf1W5_ASILD.c",
	stack: 491,
	stackTotal: 548};
	 this.metricsArray.fcn["mrdiv_sf9dmdVE_ASILD"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\_sharedutils\\mrdiv_sf9dmdVE_ASILD.c",
	stack: 244,
	stackTotal: 244};
	 this.metricsArray.fcn["mtimes_rj1908GZ_ASILD"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\_sharedutils\\mtimes_rj1908GZ_ASILD.c",
	stack: 12,
	stackTotal: 12};
	 this.metricsArray.fcn["norm_o3AfMSX6_ASILD"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\_sharedutils\\norm_o3AfMSX6_ASILD.c",
	stack: 36,
	stackTotal: 36};
	 this.metricsArray.fcn["pow"] = {file: "T:\\jobarchive\\Bmain\\2021_09_16_h11m17s30_job1767943_pass\\matlab\\polyspace\\verifier\\cxx\\include\\include-libc\\bits\\mathcalls.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["qpkwik_zOiTiUrm_ASILD"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\_sharedutils\\qpkwik_zOiTiUrm_ASILD.c",
	stack: 3515,
	stackTotal: 5447};
	 this.metricsArray.fcn["qr_8vc6RuhJ_ASILD"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\_sharedutils\\qr_8vc6RuhJ_ASILD.c",
	stack: 606,
	stackTotal: 646};
	 this.metricsArray.fcn["rt_hypotd_ASILD"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\_sharedutils\\rt_hypotd_ASILD.c",
	stack: 24,
	stackTotal: 24};
	 this.metricsArray.fcn["rt_roundd_ASILD"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\_sharedutils\\rt_roundd_ASILD.c",
	stack: 8,
	stackTotal: 8};
	 this.metricsArray.fcn["sqrt"] = {file: "T:\\jobarchive\\Bmain\\2021_09_16_h11m17s30_job1767943_pass\\matlab\\polyspace\\verifier\\cxx\\include\\include-libc\\bits\\mathcalls.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["trisolve_bbtHhwaz_ASILD"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\_sharedutils\\trisolve_bbtHhwaz_ASILD.c",
	stack: 36,
	stackTotal: 36};
	 this.metricsArray.fcn["xgemv_6OX2SCO5_ASILD"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\_sharedutils\\xgemv_6OX2SCO5_ASILD.c",
	stack: 32,
	stackTotal: 32};
	 this.metricsArray.fcn["xgerc_CjD4Pmj0_ASILD"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\_sharedutils\\xgerc_CjD4Pmj0_ASILD.c",
	stack: 40,
	stackTotal: 40};
	 this.metricsArray.fcn["xnrm2_CVSaOtJB_ASILD"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\_sharedutils\\xnrm2_CVSaOtJB_ASILD.c",
	stack: 40,
	stackTotal: 40};
	 this.metricsArray.fcn["xpotrf_YRopEtIA_ASILD"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\_sharedutils\\xpotrf_YRopEtIA_ASILD.c",
	stack: 57,
	stackTotal: 57};
	 this.getMetrics = function(token) { 
		 var data;
		 data = this.metricsArray.var[token];
		 if (!data) {
			 data = this.metricsArray.fcn[token];
			 if (data) data.type = "fcn";
		 } else { 
			 data.type = "var";
		 }
	 return data; }; 
	 this.codeMetricsSummary = '<a href="javascript:void(0)" onclick="return postParentWindowMessage({message:\'gotoReportPage\', pageName:\'MPCController_metrics\'});">Global Memory: 0(bytes) Maximum Stack: 43214(bytes)</a>';
	}
CodeMetrics.instance = new CodeMetrics();
