function CodeMetrics() {
	 this.metricsArray = {};
	 this.metricsArray.var = new Array();
	 this.metricsArray.fcn = new Array();
	 this.metricsArray.fcn["PreviewCurvature"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\PreviewCurvature\\PreviewCurvature.c",
	stack: 28,
	stackTotal: 28};
	 this.getMetrics = function(token) { 
		 var data;
		 data = this.metricsArray.var[token];
		 if (!data) {
			 data = this.metricsArray.fcn[token];
			 if (data) data.type = "fcn";
		 } else { 
			 data.type = "var";
		 }
	 return data; }; 
	 this.codeMetricsSummary = '<a href="javascript:void(0)" onclick="return postParentWindowMessage({message:\'gotoReportPage\', pageName:\'PreviewCurvature_metrics\'});">Global Memory: 0(bytes) Maximum Stack: 28(bytes)</a>';
	}
CodeMetrics.instance = new CodeMetrics();
