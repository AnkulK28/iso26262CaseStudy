function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "ControllerModeSelector"};
	this.sidHashMap["ControllerModeSelector"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<Root>/Acceleration"] = {sid: "ControllerModeSelector:19"};
	this.sidHashMap["ControllerModeSelector:19"] = {rtwname: "<Root>/Acceleration"};
	this.rtwnameHashMap["<Root>/WatchdogBrake"] = {sid: "ControllerModeSelector:20"};
	this.sidHashMap["ControllerModeSelector:20"] = {rtwname: "<Root>/WatchdogBrake"};
	this.rtwnameHashMap["<Root>/Deceleration"] = {sid: "ControllerModeSelector:21"};
	this.sidHashMap["ControllerModeSelector:21"] = {rtwname: "<Root>/Deceleration"};
	this.rtwnameHashMap["<Root>/Constant"] = {sid: "ControllerModeSelector:31"};
	this.sidHashMap["ControllerModeSelector:31"] = {rtwname: "<Root>/Constant"};
	this.rtwnameHashMap["<Root>/GreaterThan"] = {sid: "ControllerModeSelector:30"};
	this.sidHashMap["ControllerModeSelector:30"] = {rtwname: "<Root>/GreaterThan"};
	this.rtwnameHashMap["<Root>/Saturation"] = {sid: "ControllerModeSelector:23"};
	this.sidHashMap["ControllerModeSelector:23"] = {rtwname: "<Root>/Saturation"};
	this.rtwnameHashMap["<Root>/Switch"] = {sid: "ControllerModeSelector:24"};
	this.sidHashMap["ControllerModeSelector:24"] = {rtwname: "<Root>/Switch"};
	this.rtwnameHashMap["<Root>/UnaryMinus"] = {sid: "ControllerModeSelector:29"};
	this.sidHashMap["ControllerModeSelector:29"] = {rtwname: "<Root>/UnaryMinus"};
	this.rtwnameHashMap["<Root>/AccelerationCmd"] = {sid: "ControllerModeSelector:25"};
	this.sidHashMap["ControllerModeSelector:25"] = {rtwname: "<Root>/AccelerationCmd"};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
