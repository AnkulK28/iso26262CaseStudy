function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "HighwayLaneFollowingController"};
	this.sidHashMap["HighwayLaneFollowingController"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<Root>/Lanes"] = {sid: "HighwayLaneFollowingController:47"};
	this.sidHashMap["HighwayLaneFollowingController:47"] = {rtwname: "<Root>/Lanes"};
	this.rtwnameHashMap["<Root>/confirmedTracks"] = {sid: "HighwayLaneFollowingController:48"};
	this.sidHashMap["HighwayLaneFollowingController:48"] = {rtwname: "<Root>/confirmedTracks"};
	this.rtwnameHashMap["<Root>/longVelocity"] = {sid: "HighwayLaneFollowingController:49"};
	this.sidHashMap["HighwayLaneFollowingController:49"] = {rtwname: "<Root>/longVelocity"};
	this.rtwnameHashMap["<Root>/SetVelocity"] = {sid: "HighwayLaneFollowingController:50"};
	this.sidHashMap["HighwayLaneFollowingController:50"] = {rtwname: "<Root>/SetVelocity"};
	this.rtwnameHashMap["<Root>/DetectMIOLaneCenter"] = {sid: "HighwayLaneFollowingController:53"};
	this.sidHashMap["HighwayLaneFollowingController:53"] = {rtwname: "<Root>/DetectMIOLaneCenter"};
	this.rtwnameHashMap["<Root>/EstimatePathDeviations"] = {sid: "HighwayLaneFollowingController:55"};
	this.sidHashMap["HighwayLaneFollowingController:55"] = {rtwname: "<Root>/EstimatePathDeviations"};
	this.rtwnameHashMap["<Root>/LaneFollowingController"] = {sid: "HighwayLaneFollowingController:44"};
	this.sidHashMap["HighwayLaneFollowingController:44"] = {rtwname: "<Root>/LaneFollowingController"};
	this.rtwnameHashMap["<Root>/SteeringCmd"] = {sid: "HighwayLaneFollowingController:45"};
	this.sidHashMap["HighwayLaneFollowingController:45"] = {rtwname: "<Root>/SteeringCmd"};
	this.rtwnameHashMap["<Root>/AccelertionCmd"] = {sid: "HighwayLaneFollowingController:46"};
	this.sidHashMap["HighwayLaneFollowingController:46"] = {rtwname: "<Root>/AccelertionCmd"};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
