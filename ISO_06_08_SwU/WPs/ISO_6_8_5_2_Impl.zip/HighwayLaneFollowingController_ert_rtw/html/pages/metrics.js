function CodeMetrics() {
	 this.metricsArray = {};
	 this.metricsArray.var = new Array();
	 this.metricsArray.fcn = new Array();
	 this.metricsArray.var["HighwayLaneFollowingControll_DW"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\HighwayLaneFollowingController_ert_rtw\\HighwayLaneFollowingController.c",
	size: 272760};
	 this.metricsArray.var["HighwayLaneFollowingControlle_U"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\HighwayLaneFollowingController_ert_rtw\\HighwayLaneFollowingController.c",
	size: 42488};
	 this.metricsArray.var["HighwayLaneFollowingControlle_Y"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\HighwayLaneFollowingController_ert_rtw\\HighwayLaneFollowingController.c",
	size: 16};
	 this.metricsArray.fcn["DetectMIOLaneCenter"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\DetectMIOLaneCenter\\DetectMIOLaneCenter.c",
	stack: 72,
	stackTotal: 216};
	 this.metricsArray.fcn["DetectMIOLaneCenter_Init"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\DetectMIOLaneCenter\\DetectMIOLaneCenter.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["DetectMIOLaneCenter_initialize"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\DetectMIOLaneCenter\\DetectMIOLaneCenter.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["HighwayLaneFollowingController_initialize"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\HighwayLaneFollowingController_ert_rtw\\HighwayLaneFollowingController.c",
	stack: 0,
	stackTotal: 12};
	 this.metricsArray.fcn["HighwayLaneFollowingController_step"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\HighwayLaneFollowingController_ert_rtw\\HighwayLaneFollowingController.c",
	stack: 296,
	stackTotal: 71521};
	 this.metricsArray.fcn["LF_Controller"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\LF_Controller\\LF_Controller.c",
	stack: 8,
	stackTotal: 71225};
	 this.metricsArray.fcn["LF_Controller_Init"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\LF_Controller\\LF_Controller.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LF_Controller_initialize"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\LF_Controller\\LF_Controller.c",
	stack: 0,
	stackTotal: 12};
	 this.metricsArray.fcn["PreviewCurvature"] = {file: "F:\\work_dir\\demos\\iso\\iso26262CaseStudy\\ISO_06_08_SwU\\WPs\\ISO_6_8_5_2_Impl\\slprj\\ert\\PreviewCurvature\\PreviewCurvature.c",
	stack: 28,
	stackTotal: 28};
	 this.metricsArray.fcn["memset"] = {file: "T:\\jobarchive\\Bmain\\2021_09_16_h11m17s30_job1767943_pass\\matlab\\polyspace\\verifier\\cxx\\include\\include-libc\\string.h",
	stack: 0,
	stackTotal: 0};
	 this.getMetrics = function(token) { 
		 var data;
		 data = this.metricsArray.var[token];
		 if (!data) {
			 data = this.metricsArray.fcn[token];
			 if (data) data.type = "fcn";
		 } else { 
			 data.type = "var";
		 }
	 return data; }; 
	 this.codeMetricsSummary = '<a href="javascript:void(0)" onclick="return postParentWindowMessage({message:\'gotoReportPage\', pageName:\'HighwayLaneFollowingController_metrics\'});">Global Memory: 315264(bytes) Maximum Stack: 296(bytes)</a>';
	}
CodeMetrics.instance = new CodeMetrics();
